bl_info = {
    "name": "Image to Material Pro (Locks + Assets + Smart Names + Palettes)",
    "author": "Steve Warner & ChatGPT",
    "version": (1, 10, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Img2Mat",
    "description": "Comfy-style RGB K-Means + Top-N, uniform grid sampling, lock colors with exact snapping, Asset materials, Image-Editor sync, and Blender Palette creation.",
    "category": "Material",
}

import bpy
import colorsys
import random
from typing import List, Tuple, Dict, Optional
from bpy.props import (
    PointerProperty, FloatProperty, BoolProperty, IntProperty, EnumProperty,
    FloatVectorProperty, StringProperty, CollectionProperty
)
from bpy.types import Panel, Operator, PropertyGroup, UIList

# ========= sRGB <-> Linear =========

def _srgb_to_linear(c):
    if c <= 0.04045: return c / 12.92
    return ((c + 0.055) / 1.055) ** 2.4

def _linear_to_srgb(c):
    if c <= 0.0031308: return 12.92 * c
    return 1.055 * (c ** (1.0 / 2.4)) - 0.055

def tuple_srgb_to_linear(rgb):
    r, g, b = rgb
    return (_srgb_to_linear(r), _srgb_to_linear(g), _srgb_to_linear(b))

def tuple_linear_to_srgb(rgb):
    r, g, b = rgb
    return (_linear_to_srgb(r), _linear_to_srgb(g), _linear_to_srgb(b))

# ========= CSS names + helpers =========

CSS_UNION_HEX_TO_NAMES: Dict[str, str] = {
    "#000000":"black","#000080":"navy","#00008b":"darkblue","#0000cd":"mediumblue","#0000ff":"blue",
    "#006400":"darkgreen","#008000":"green","#008080":"teal","#008b8b":"darkcyan","#00bfff":"deepskyblue",
    "#00ced1":"darkturquoise","#00fa9a":"mediumspringgreen","#00ff00":"lime","#00ffff":"aqua",
    "#191970":"midnightblue","#1e90ff":"dodgerblue","#20b2aa":"lightseagreen","#228b22":"forestgreen",
    "#2e8b57":"seagreen","#2f4f4f":"darkslategray","#32cd32":"limegreen","#3cb371":"mediumseagreen",
    "#40e0d0":"turquoise","#4169e1":"royalblue","#4682b4":"steelblue","#483d8b":"darkslateblue",
    "#4b0082":"indigo","#556b2f":"darkolivegreen","#5f9ea0":"cadetblue","#6495ed":"cornflowerblue",
    "#66cdaa":"mediumaquamarine","#6a5acd":"slateblue","#6b8e23":"olivedrab","#708090":"slategray",
    "#778899":"lightslategray","#7b68ee":"mediumslateblue","#7cfc00":"lawngreen","#7fff00":"chartreuse",
    "#7fffd4":"aquamarine","#800000":"maroon","#800080":"purple","#808000":"olive","#808080":"gray",
    "#87ceeb":"skyblue","#87cefa":"lightskyblue","#8a2be2":"blueviolet","#8b0000":"darkred",
    "#8b4513":"saddlebrown","#8fbc8f":"darkseagreen","#90ee90":"lightgreen","#9370db":"mediumpurple",
    "#98fb98":"palegreen","#9acd32":"yellowgreen","#a0522d":"sienna","#a52a2a":"brown","#a9a9a9":"darkgray",
    "#add8e6":"lightblue","#adff2f":"greenyellow","#b0c4de":"lightsteelblue","#b0e0e6":"powderblue",
    "#b22222":"firebrick","#bc8f8f":"rosybrown","#c0c0c0":"silver","#c71585":"mediumvioletred",
    "#cd5c5c":"indianred","#cd853f":"peru","#d2691e":"chocolate","#d2b48c":"tan","#d3d3d3":"lightgrey",
    "#d8bfd8":"thistle","#daa520":"goldenrod","#db7093":"palevioletred","#dc143c":"crimson",
    "#deb887":"burlywood","#e0ffff":"lightcyan","#e6e6fa":"lavender","#e9967a":"darksalmon",
    "#ee82ee":"violet","#eee8aa":"palegoldenrod","#f08080":"lightcoral","#f0e68c":"khaki",
    "#f0f8ff":"aliceblue","#f0fff0":"honeydew","#f0ffff":"azure","#f4a460":"sandybrown","#f5deb3":"wheat",
    "#f5f5dc":"beige","#f5f5f5":"whitesmoke","#f5fffa":"mintcream","#f8f8ff":"ghostwhite","#fa8072":"salmon",
    "#faebd7":"antiquewhite","#faf0e6":"linen","#fafad2":"lightgoldenrodyellow","#fbceb1":"apricot",
    "#fdf5e6":"oldlace","#ff0000":"red","#ff00ff":"fuchsia","#ff1493":"deeppink","#ff4500":"orangered",
    "#ff6347":"tomato","#ff69b4":"hotpink","#ff7f50":"coral","#ff8c00":"darkorange","#ffa07a":"lightsalmon",
    "#ffa500":"orange","#ffb6c1":"lightpink","#ffc0cb":"pink","#ffd700":"gold","#ffdab9":"peachpuff",
    "#ffdead":"navajowhite","#ffe4b5":"moccasin","#ffe4c4":"bisque","#ffe4e1":"mistyrose","#ffebcd":"blanchedalmond",
    "#ffefd5":"papayawhip","#fff0f5":"lavenderblush","#fff5ee":"seashell","#fff8dc":"cornsilk",
    "#fffacd":"lemonchiffon","#fffaf0":"floralwhite","#ffff00":"yellow","#ffffe0":"lightyellow","#ffffff":"white"
}

def nearest_css_name_distance(r8, g8, b8):
    best_name, best_d, best_hex = "color", 1e9, None
    for hex_str, name in CSS_UNION_HEX_TO_NAMES.items():
        rr,gg,bb = int(hex_str[1:3],16), int(hex_str[3:5],16), int(hex_str[5:7],16)
        d = abs(r8-rr) + abs(g8-gg) + abs(b8-bb)
        if d < best_d:
            best_d, best_name, best_hex = d, name, hex_str
    return best_name.title(), best_d, best_hex

def hue_family_from_h(hdeg):
    h = hdeg % 360.0
    if h < 12 or h >= 348: return "Red"
    if h < 36: return "Orange"
    if h < 60: return "Yellow"
    if h < 96: return "Yellow-Green"
    if h < 156: return "Green"
    if h < 192: return "Cyan"
    if h < 264: return "Blue"
    if h < 312: return "Magenta"
    return "Red-Magenta"

def tone_prefix(s, v):
    if v < 0.22: return "Black"
    if v > 0.92 and s < 0.18: return "White"
    if s < 0.12: return "Gray"
    if v < 0.40: return "Dark"
    if v > 0.80 and s < 0.70: return "Light"
    if s < 0.40: return "Muted"
    return ""

def descriptive_name_from_rgb(rgb):
    h,s,v = colorsys.rgb_to_hsv(*rgb)
    fam = hue_family_from_h(h*360.0)
    t = tone_prefix(s, v)
    return f"{t + ' ' if t else ''}{fam}"

def css_hue_guard_name_from_rgb(rgb):
    r8,g8,b8 = [max(0, min(255, round(v*255))) for v in rgb]
    css_name, dist, _ = nearest_css_name_distance(r8,g8,b8)
    h,s,v = colorsys.rgb_to_hsv(*rgb)
    fam = hue_family_from_h(h*360.0)
    if v < 0.22 or (v > 0.92 and s < 0.18) or s < 0.12:
        return css_name.title()
    fam_map = {
        "Red":["red","crimson","maroon","firebrick","tomato","coral","orangered"],
        "Orange":["orange","sandybrown","chocolate","peru","sienna","peach","apricot","goldenrod"],
        "Yellow":["yellow","khaki","gold","lemon","ivory"],
        "Green":["green","olive","chartreuse","lime","teal","seagreen","turquoise"],
        "Cyan":["cyan","aqua","turquoise"],
        "Blue":["blue","navy","royal","sky","indigo","slate"],
        "Magenta":["magenta","fuchsia","pink","violet","plum","orchid"],
        "Red-Magenta":["magenta","red","crimson","fuchsia","pink","violet","plum","orchid"],
        "Yellow-Green":["yellow","green","olive","chartreuse","lime"],
    }
    lower = css_name.lower()
    mismatch = not any(tok in lower for tok in fam_map.get(fam, []))
    if dist > 90 or mismatch:
        return descriptive_name_from_rgb(rgb)
    return css_name.title()

def rgb_to_hex(rgb):
    r,g,b = [max(0, min(255, round(v*255))) for v in rgb]
    return f"#{r:02X}{g:02X}{b:02X}"

# ========= Image reading =========

def _get_pixels_linear(image: bpy.types.Image):
    if not image.has_data:
        image.pixels[:]
    px = list(image.pixels)
    w, h = image.size
    return w, h, [tuple(px[i:i+4]) for i in range(0, len(px), 4)]

def read_pixels_as_is(image: bpy.types.Image, stride=1, alpha_min=0.05):
    w,h,data = _get_pixels_linear(image)
    out = []
    idx = 0
    for y in range(h):
        for x in range(w):
            r,g,b,a = data[idx]; idx += 1
            if ((x + y*w) % max(1,stride)) != 0: continue
            if a < alpha_min: continue
            out.append((max(0,min(1,r)), max(0,min(1,g)), max(0,min(1,b))))
    return out

def read_pixels_linear_to_srgb(image: bpy.types.Image, stride=1, alpha_min=0.05):
    w,h,data = _get_pixels_linear(image)
    out = []
    idx = 0
    for y in range(h):
        for x in range(w):
            r_lin,g_lin,b_lin,a = data[idx]; idx += 1
            if ((x + y*w) % max(1,stride)) != 0: continue
            if a < alpha_min: continue
            out.append(tuple_linear_to_srgb((r_lin,g_lin,b_lin)))
    return out

def read_pixels_uniform_grid(image: bpy.types.Image, cells=64, alpha_min=0.05, as_is=True):
    w,h,data = _get_pixels_linear(image)
    out = []
    cell_w = max(1, w // cells)
    cell_h = max(1, h // cells)
    for gy in range(cells):
        for gx in range(cells):
            cx = min(w-1, gx*cell_w + cell_w//2)
            cy = min(h-1, gy*cell_h + cell_h//2)
            idx = cy*w + cx
            r,g,b,a = data[idx]
            if a < alpha_min: continue
            if as_is:
                out.append((max(0,min(1,r)), max(0,min(1,g)), max(0,min(1,b))))
            else:
                out.append(tuple_linear_to_srgb((r,g,b)))
    return out

# ========= K-Means & Top-N =========

def kmeans_rgb_with_locks(points, k=9, iters=300, seed=0, locked=None):
    if not points: return []
    if locked is None: locked = []
    rnd = random.Random(seed)
    pts = points

    centroids = list(locked[:k])
    anchored = set(range(len(centroids)))

    need = max(0, k - len(centroids))
    if need > 0:
        if not centroids:
            centroids.append(pts[rnd.randrange(len(pts))])
        for _ in range(need):
            d2 = []
            for p in pts:
                mind = min((p[0]-c[0])**2 + (p[1]-c[1])**2 + (p[2]-c[2])**2 for c in centroids)
                d2.append(mind)
            total = sum(d2) or 1.0
            r = rnd.random() * total; upto = 0.0
            for p, w in zip(pts, d2):
                upto += w
                if upto >= r:
                    centroids.append(p); break

    for _ in range(iters):
        buckets = [[] for _ in range(k)]
        for p in pts:
            idx = min(range(k), key=lambda i: (p[0]-centroids[i][0])**2 + (p[1]-centroids[i][1])**2 + (p[2]-centroids[i][2])**2)
            buckets[idx].append(p)
        newc = []
        for i, b in enumerate(buckets):
            if i in anchored:
                newc.append(centroids[i])
            else:
                if b:
                    r = sum(p[0] for p in b)/len(b)
                    g = sum(p[1] for p in b)/len(b)
                    bb = sum(p[2] for p in b)/len(b)
                    newc.append((r,g,bb))
                else:
                    newc.append(pts[rnd.randrange(len(pts))])
        if all((abs(nc[0]-c[0])<1e-7 and abs(nc[1]-c[1])<1e-7 and abs(nc[2]-c[2])<1e-7) for nc,c in zip(newc,centroids)):
            centroids = newc; break
        centroids = newc

    centroids.sort(key=lambda rgb: (colorsys.rgb_to_hsv(*rgb)[2], colorsys.rgb_to_hsv(*rgb)[0]), reverse=True)
    return centroids

def unique_top_n_with_locks(points, n=9, min_pct=0.002, locked=None):
    if locked is None: locked = []
    counts: Dict[Tuple[int,int,int], int] = {}
    for r,g,b in points:
        rr = max(0, min(255, round(r*255)))
        gg = max(0, min(255, round(g*255)))
        bb = max(0, min(255, round(b*255)))
        counts[(rr,gg,bb)] = counts.get((rr,gg,bb), 0) + 1
    total = max(1, sum(counts.values()))
    items = [(rgb,c) for rgb,c in counts.items() if (c/total) >= min_pct]
    if not items: items = list(counts.items())
    items.sort(key=lambda x: x[1], reverse=True)

    out, seen = [], set()
    for r,g,b in locked:
        rr = max(0, min(255, round(r*255)))
        gg = max(0, min(255, round(g*255)))
        bb = max(0, min(255, round(b*255)))
        key = (rr,gg,bb)
        if key not in seen:
            out.append((rr/255.0, gg/255.0, bb/255.0))
            seen.add(key)
        if len(out) >= n:
            break

    for (rr,gg,bb), _ in items:
        if len(out) >= n: break
        if (rr,gg,bb) in seen: continue
        out.append((rr/255.0, gg/255.0, bb/255.0))
        seen.add((rr,gg,bb))

    out.sort(key=lambda rgb: (colorsys.rgb_to_hsv(*rgb)[2], colorsys.rgb_to_hsv(*rgb)[0]), reverse=True)
    return out

# ========= Materials / swatches / labels / palette =========

def ensure_collection(name: str):
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(coll)
    return coll

def clear_collection_objects(coll: bpy.types.Collection):
    for obj in list(coll.objects):
        bpy.data.objects.remove(obj, do_unlink=True)

def set_if_socket_exists(node, socket_name, value):
    inp = node.inputs.get(socket_name)
    if inp is not None:
        inp.default_value = value
        return True
    return False

def create_material_from_srgb(name: str, rgb_srgb, subsurf=0.0, mark_asset=False, asset_tag=""):
    r_s, g_s, b_s = [max(0.0, min(1.0, v)) for v in rgb_srgb]
    r_lin, g_lin, b_lin = tuple_srgb_to_linear((r_s, g_s, b_s))
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (r_lin, g_lin, b_lin, 1.0)
        if not set_if_socket_exists(bsdf, "Subsurface", subsurf):
            set_if_socket_exists(bsdf, "Subsurface Weight", subsurf)
    if mark_asset and hasattr(mat, "asset_mark"):
        mat.asset_mark()
        if asset_tag:
            try: mat.asset_data.tags.new(asset_tag)
            except Exception: pass
    return mat

def create_swatch_plane(x, y, size=1.6):
    mesh = bpy.data.meshes.new("Img2Mat_Swatch")
    obj = bpy.data.objects.new("Img2Mat_Swatch", mesh)
    verts = [(x, y, 0), (x+size, y, 0), (x+size, y+size, 0), (x, y+size, 0)]
    faces = [(0,1,2,3)]
    mesh.from_pydata(verts, [], faces); mesh.update()
    return obj

def create_label(text, x, y):
    txt = bpy.data.curves.new(type="FONT", name="Img2Mat_Label")
    obj = bpy.data.objects.new("Img2Mat_Label", txt)
    txt.body = text
    txt.align_x = 'CENTER'
    # Start with a readable default size; we'll scale-to-fit below after linking
    txt.size = 1.0
    obj.location = (x + 0.8, y - 0.15, 0)  # center under a 1.6-size swatch
    obj.scale = (0.2, 0.2, 0.2)
    return obj

def fit_label_to_width(obj, max_width: float):
    """Scale the FONT object so its final width does not exceed max_width."""
    try:
        bpy.context.view_layer.update()
        width = obj.dimensions.x
        if width <= 0.0:
            return
        # current overall width includes current scale
        current_scale = obj.scale.x
        effective_width = width * current_scale
        if effective_width > max_width:
            factor = max_width / effective_width
            obj.scale = (current_scale * factor, current_scale * factor, current_scale * factor)
            bpy.context.view_layer.update()
    except Exception:
        pass

def ensure_palette(name: str):
    pal = bpy.data.palettes.get(name)
    if pal is None:
        pal = bpy.data.palettes.new(name)
    while pal.colors:
        pal.colors.remove(pal.colors[-1])
    return pal

# ========= Lock Colors data & UI =========

class IMG2MAT_ColorItem(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", default="")
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 0.0, 0.0))

class IMG2MAT_UL_LockColors(UIList):
    bl_idname = "IMG2MAT_UL_LockColors"
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "color", text="")
        row.prop(item, "name", text="", emboss=False)

class IMG2MAT_OT_LockAdd(Operator):
    bl_idname = "img2mat.lock_add"
    bl_label = "Add Lock Color"
    def execute(self, context):
        p = context.scene.img2mat_props
        item = p.lock_colors.add()
        item.name = f"Lock {len(p.lock_colors)}"
        p.lock_index = len(p.lock_colors)-1
        return {'FINISHED'}

class IMG2MAT_OT_LockRemove(Operator):
    bl_idname = "img2mat.lock_remove"
    bl_label = "Remove Lock Color"
    def execute(self, context):
        p = context.scene.img2mat_props
        if p.lock_colors and 0 <= p.lock_index < len(p.lock_colors):
            p.lock_colors.remove(p.lock_index)
            p.lock_index = min(p.lock_index, len(p.lock_colors)-1)
        return {'FINISHED'}

# ========= Active Image helpers =========

def find_active_image_from_editors() -> Optional[bpy.types.Image]:
    for area in bpy.context.screen.areas:
        if area.type == 'IMAGE_EDITOR':
            for space in area.spaces:
                if space.type == 'IMAGE_EDITOR':
                    img = getattr(space, "image", None)
                    if img is not None:
                        return img
    return None

class IMG2MAT_OT_UseActiveImage(Operator):
    bl_idname = "img2mat.use_active_image"
    bl_label = "Use Active Image (Image Editor)"
    def execute(self, context):
        p = context.scene.img2mat_props
        img = find_active_image_from_editors()
        if img is None:
            self.report({'WARNING'}, "No Image Editor image found.")
            return {'CANCELLED'}
        p.image = img
        self.report({'INFO'}, f"Using active image: {img.name}")
        return {'FINISHED'}

# ========= UI Props =========

class IMG2MAT_Props(PropertyGroup):
    # Collapsible "Options" header state
    options_expanded: BoolProperty(
        name="Options",
        description="Show advanced options for color extraction, naming, and output",
        default=False
    )

    method: EnumProperty(
        name="Color Sampling Method",
        description="How colors are extracted from the image",
        items=[
            ('KMEANS_RGB', "K-Means (RGB, Comfy)", "Cluster RGB pixels (Comfy-like)"),
            ('POSTER', "Poster Unique (Top-N)", "Choose most frequent exact sRGB colors"),
        ],
        default='KMEANS_RGB'
    )
    palette_size: IntProperty(name="Palette Size", min=2, max=64, default=8, description="Number of colors to extract for the palette")

    image: PointerProperty(type=bpy.types.Image, name="Image", description="Source image")

    sync_active_image: BoolProperty(
        name="Sync with Image Viewer",
        description="When enabled, Generate Materials will always use the image shown in any open Image Editor",
        default=True
    )

    pixel_colorspace: EnumProperty(
        name="Color Space",
        description="Interpretation of the image pixel values when sampling",
        items=[
            ('AS_IS', "As-Is (sRGB)", "Treat image.pixels as sRGB (best for PNG/JPEG)"),
            ('LIN_TO_SRGB', "Linear to sRGB", "Convert from linear to sRGB"),
        ],
        default='AS_IS'
    )

    sampling: EnumProperty(
        name="Sampling",
        description="Strategy for picking which pixels to analyze",
        items=[
            ('STRIDE', "All Pixels (stride)", "Use every Nth pixel across the whole image"),
            ('GRID', "Uniform Grid", "Sample one pixel per cell to de-bias large regions"),
        ],
        default='GRID'
    )
    sample_stride: IntProperty(name="Pixel Stride", min=1, max=64, default=1, description="Use every Nth pixel when 'All Pixels (stride)' is selected")
    grid_cells: IntProperty(name="Grid Size", min=8, max=256, default=64, description="Number of cells per dimension when using Uniform Grid sampling")
    alpha_min: FloatProperty(name="Min Alpha", min=0.0, max=1.0, default=0.05, description="Ignore pixels with alpha below this value")

    poster_min_percent: FloatProperty(name="Min % (Poster)", min=0.0, max=0.05, default=0.002, description="Minimum frequency threshold for Poster Unique method")

    accuracy: IntProperty(name="Accuracy", min=1, max=100, default=80, description="Higher = more K-Means iterations (more accurate but slower)")
    seed: IntProperty(name="Seed", min=0, max=2**31-1, default=0, description="Random seed for K-Means initialization")

    lock_colors: CollectionProperty(type=IMG2MAT_ColorItem)
    lock_index: IntProperty(name="Active Lock", default=0)
    use_lock_names: BoolProperty(name="Use Lock Names", default=True, description="If a palette color exactly matches a lock color, use the lock's name")
    lock_snap_tol: IntProperty(name="Lock Snap Tolerance (8-bit L1)", min=0, max=30, default=6, description="Snap extracted colors to nearby lock colors within this 8-bit L1 distance")

    naming_mode: EnumProperty(
        name="Naming",
        description="How to name generated materials",
        items=[
            ('CSS', "CSS", "Nearest CSS/HTML color"),
            ('CSS_GUARD', "CSS + Hue Guard", "Use CSS unless it clashes with hue/tone or is far"),
            ('HUE', "Hue Descriptive", "Descriptive names from hue + tone"),
        ],
        default='CSS_GUARD'
    )

    subsurface: FloatProperty(name="Subsurface", min=0.0, max=1.0, default=0.0, description="Set Subsurface/SSS on generated Principled BSDF materials")
    generate_swatches: BoolProperty(name="Generate Swatches", default=True, description="Create a grid of colored planes for quick viewing")
    generate_labels: BoolProperty(name="Generate Labels", default=True, description="Add text labels beneath swatches (auto-sized to fit)")

    mark_as_assets: BoolProperty(name="Mark Materials as Assets", default=True, description="Mark materials as Assets and tag them")
    asset_tag: StringProperty(name="Asset Tag", default="palette", description="Tag name to add to generated Assets")

    create_palette: BoolProperty(name="Create Blender Palette", default=True, description="Create a Blender Palette resource with these colors")
    palette_name: StringProperty(name="Palette Name", default="Img2Mat Palette", description="Name of the Blender Palette asset to create")

# ========= helpers for locks/snapping =========

def get_locked_colors_srgb(p):
    locks_srgb = []
    for item in p.lock_colors:
        col_lin = tuple(item.color)
        col_srgb = tuple_linear_to_srgb(col_lin)
        locks_srgb.append(tuple(max(0.0, min(1.0, v)) for v in col_srgb))
    return locks_srgb

def snap_to_locked_colors(colors, locks, tol_l1_8bit):
    if not locks or tol_l1_8bit <= 0:
        return colors
    locks8 = [tuple(max(0, min(255, round(c*255))) for c in lock) for lock in locks]
    snapped = []
    for rgb in colors:
        r8,g8,b8 = [max(0, min(255, round(v*255))) for v in rgb]
        replaced = False
        for lr,lg,lb in locks8:
            d = abs(r8-lr) + abs(g8-lg) + abs(b8-lb)
            if d <= tol_l1_8bit:
                snapped.append((lr/255.0, lg/255.0, lb/255.0))
                replaced = True
                break
        if not replaced:
            snapped.append(rgb)
    return snapped

# ========= Generate Operator =========

class IMG2MAT_OT_Generate(Operator):
    bl_idname = "img2mat.generate_materials"
    bl_label = "Generate Materials"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        p = context.scene.img2mat_props

        image = p.image
        if p.sync_active_image or image is None:
            image = find_active_image_from_editors() or image
        if image is None:
            self.report({"ERROR"}, "No image selected (and none visible in Image Editor).")
            return {"CANCELLED"}
        p.image = image

        as_is = (p.pixel_colorspace == 'AS_IS')
        if p.sampling == 'GRID':
            samples = read_pixels_uniform_grid(image, cells=p.grid_cells, alpha_min=p.alpha_min, as_is=as_is)
        else:
            samples = read_pixels_as_is(image, stride=p.sample_stride, alpha_min=p.alpha_min) if as_is \
                    else read_pixels_linear_to_srgb(image, stride=p.sample_stride, alpha_min=p.alpha_min)
        if not samples:
            self.report({"WARNING"}, "No samples; check alpha/sampling settings")
            return {"CANCELLED"}

        locks_srgb = get_locked_colors_srgb(p)
        k = p.palette_size
        if locks_srgb and len(locks_srgb) > k:
            locks_srgb = locks_srgb[:k]

        if p.method == 'KMEANS_RGB':
            iters = int(512 * (p.accuracy / 100))
            palette = kmeans_rgb_with_locks(samples, k=k, iters=iters, seed=p.seed, locked=locks_srgb)
        else:
            palette = unique_top_n_with_locks(samples, n=k, min_pct=p.poster_min_percent, locked=locks_srgb)
        if not palette:
            self.report({"WARNING"}, "Palette extraction produced 0 colors.")
            return {"CANCELLED"}

        palette = snap_to_locked_colors(palette, locks_srgb, p.lock_snap_tol)

        lock_name_map = {}
        if p.use_lock_names:
            for item in p.lock_colors:
                nm = item.name.strip()
                if not nm: continue
                srgb = tuple_linear_to_srgb(tuple(item.color))
                r8 = max(0, min(255, round(srgb[0]*255)))
                g8 = max(0, min(255, round(srgb[1]*255)))
                b8 = max(0, min(255, round(srgb[2]*255)))
                lock_name_map[(r8,g8,b8)] = nm

        sw_coll = ensure_collection("HueSwatches") if p.generate_swatches else None
        if sw_coll: clear_collection_objects(sw_coll)
        pal = ensure_palette(p.palette_name) if p.create_palette else None

        grid_x = grid_y = 0; max_cols = 10
        for rgb in palette:
            r8,g8,b8 = [max(0, min(255, round(v*255))) for v in rgb]
            hexcode = f"#{r8:02X}{g8:02X}{b8:02X}"

            if (r8,g8,b8) in lock_name_map:
                disp_name = lock_name_map[(r8,g8,b8)]
            else:
                if p.naming_mode == 'CSS':
                    disp_name, _, _ = nearest_css_name_distance(r8,g8,b8)
                elif p.naming_mode == 'HUE':
                    disp_name = descriptive_name_from_rgb(rgb)
                else:
                    disp_name = css_hue_guard_name_from_rgb(rgb)

            mat_name = f"{disp_name} {hexcode}"
            mat = create_material_from_srgb(
                mat_name, rgb,
                subsurf=p.subsurface,
                mark_asset=p.mark_as_assets,
                asset_tag=p.asset_tag
            )

            if sw_coll:
                sw = create_swatch_plane(grid_x * 1.8, -grid_y * 1.8, size=1.6)
                if sw.data.materials: sw.data.materials[0] = mat
                else: sw.data.materials.append(mat)
                sw_coll.objects.link(sw)
                if p.generate_labels:
                    lbl = create_label(mat_name, grid_x * 1.8, -grid_y * 1.8)
                    sw_coll.objects.link(lbl)
                    # Ensure the label never exceeds swatch width (Change #3)
                    fit_label_to_width(lbl, max_width=1.6)
                grid_x += 1
                if grid_x >= max_cols: grid_x = 0; grid_y += 1

            if pal:
                pc = pal.colors.new()
                pc.color = (rgb[0], rgb[1], rgb[2])

        if pal and hasattr(pal, "asset_mark"):
            pal.asset_mark()
            if p.asset_tag:
                try: pal.asset_data.tags.new(p.asset_tag)
                except Exception: pass

        self.report({"INFO"}, f"Generated {len(palette)} materials (locks={len(locks_srgb)}).")
        return {"FINISHED"}

# ========= Panel =========

class IMG2MAT_PT_Panel(Panel):
    bl_label = "Image to Material"
    bl_idname = "IMG2MAT_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Img2Mat"

    def draw(self, context):
        p = context.scene.img2mat_props
        col = self.layout.column(align=True)

        # --- Top: Image + Sync
        row = col.row(align=True)
        row.prop(p, "image", text="Image")
        row.operator("img2mat.use_active_image", text="", icon="IMAGE_DATA")
        col.prop(p, "sync_active_image")

        col.separator()

        # --- Palette Size
        col.prop(p, "palette_size")

        col.separator()

        # --- Lock Colors (Add / Remove / Use Lock Names)
        col.label(text="Lock Colors")
        row = col.row()
        row.template_list("IMG2MAT_UL_LockColors", "", p, "lock_colors", p, "lock_index", rows=3)
        sub = col.row(align=True)
        sub.operator("img2mat.lock_add", icon="ADD", text="Add Lock Color")
        sub.operator("img2mat.lock_remove", icon="REMOVE", text="Remove Lock Color")
        col.prop(p, "use_lock_names")
        col.separator()

        # --- Output (checkboxes only)
        box_out = col.box()
        box_out.label(text="Output")
        box_out.prop(p, "generate_swatches", text="Generate Swatches")
        box_out.prop(p, "generate_labels", text="Generate Labels")
        box_out.prop(p, "mark_as_assets", text="Mark Materials as Assets")
        box_out.prop(p, "create_palette", text="Create Blender Palette")

        col.separator()

        # --- Options (collapsed by default)
        box = col.box()
        header = box.row(align=True)
        icon = "TRIA_DOWN" if p.options_expanded else "TRIA_RIGHT"
        header.prop(p, "options_expanded", text="Options", emboss=False, icon=icon)

        if p.options_expanded:
            box.separator()
            # Color Sampling Method
            box.label(text="Color Sampling Method")
            box.prop(p, "method", text="")

            # Color Space
            box.separator()
            box.label(text="Color Space")
            box.prop(p, "pixel_colorspace", text="")

            # Sampling
            box.separator()
            box.label(text="Sampling")
            box.prop(p, "sampling", text="")
            if p.sampling == 'GRID':
                box.prop(p, "grid_cells")
            else:
                box.prop(p, "sample_stride")
            box.prop(p, "alpha_min")

            # Method-specific options
            if p.method == 'KMEANS_RGB':
                box.separator()
                box.label(text="Comfy K-Means (RGB)")
                box.prop(p, "accuracy")
                box.prop(p, "seed")
            else:
                box.separator()
                box.label(text="Poster Unique")
                box.prop(p, "poster_min_percent")

            # Lock Tolerance
            box.separator()
            box.label(text="Lock Snapping")
            box.prop(p, "lock_snap_tol")

            # Naming
            box.separator()
            box.label(text="Naming")
            box.prop(p, "naming_mode", text="")

            # Subsurface
            box.separator()
            box.label(text="Subsurface")
            box.prop(p, "subsurface")

            # Asset Tag / Palette Name
            box.separator()
            box.label(text="Assets & Palette")
            box.prop(p, "asset_tag")
            box.prop(p, "palette_name")

        col.separator()

        # --- Bottom: Generate button
        col.operator(IMG2MAT_OT_Generate.bl_idname, icon="COLOR")

# ========= Registration =========

classes = (
    IMG2MAT_ColorItem,
    IMG2MAT_UL_LockColors,
    IMG2MAT_OT_LockAdd,
    IMG2MAT_OT_LockRemove,
    IMG2MAT_OT_UseActiveImage,
    IMG2MAT_Props,
    IMG2MAT_OT_Generate,
    IMG2MAT_PT_Panel,
)

def register():
    for c in classes: bpy.utils.register_class(c)
    bpy.types.Scene.img2mat_props = PointerProperty(type=IMG2MAT_Props)

def unregister():
    for c in reversed(classes): bpy.utils.unregister_class(c)
    del bpy.types.Scene.img2mat_props

if __name__ == "__main__":
    register()
